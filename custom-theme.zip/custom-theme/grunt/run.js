module.exports = {
    jest: {
        cmd: 'npx',
        args: [
            'jest',
        ],
    },
};
